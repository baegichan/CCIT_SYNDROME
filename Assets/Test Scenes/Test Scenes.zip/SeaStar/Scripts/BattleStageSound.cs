using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleStageSound : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        SoundManager.BGLoop("BattleField");
    }

    // Update is called once per frame
  
}
