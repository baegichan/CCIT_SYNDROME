using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WolfFangsEvents : MonoBehaviour
{
    void Offthis()
    {
        gameObject.SetActive(false);
    }
}
