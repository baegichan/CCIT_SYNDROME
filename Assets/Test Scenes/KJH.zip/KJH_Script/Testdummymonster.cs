using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestDummymonster : MonoBehaviour
{
    public float Hp;

    void Start()
    {
        
    }
    
    void Update()
    {
        
    }
}
